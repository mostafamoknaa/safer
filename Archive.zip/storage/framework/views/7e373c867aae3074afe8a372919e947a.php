<?php $__env->startSection('title', __('hotel.hotels.page_title')); ?>
<?php $__env->startSection('page-title', __('hotel.hotels.heading')); ?>
<?php $__env->startSection('page-subtitle', __('hotel.hotels.subheading')); ?>

<?php $__env->startSection('content'); ?>
    <div class="rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-lg font-semibold text-slate-900"><?php echo e(__('hotel.hotels.heading')); ?></h2>
                <p class="text-sm text-slate-500"><?php echo e(__('hotel.hotels.subheading')); ?></p>
            </div>
            <a href="<?php echo e(route('hotel.hotels.create')); ?>"
               class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-slate-400/40 transition hover:bg-slate-700">
                <i class="fas fa-plus"></i>
                <?php echo e(__('hotel.hotels.actions.create')); ?>

            </a>
        </div>

        <div class="mt-6 overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200 text-right text-sm">
                <thead class="bg-slate-50 text-xs font-medium uppercase tracking-wider text-slate-500">
                    <tr>
                        <th class="px-4 py-3"><?php echo e(__('hotel.hotels.table.name')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('hotel.hotels.table.address')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('hotel.hotels.table.province')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('hotel.hotels.table.rooms')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('hotel.hotels.table.website')); ?></th>
                        <th class="px-4 py-3 text-center"><?php echo e(__('hotel.hotels.table.status')); ?></th>
                        <th class="px-4 py-3 text-center"><?php echo e(__('hotel.hotels.table.actions')); ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 bg-white">
                    <?php $__empty_1 = true; $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-4 py-4 font-semibold text-slate-800"><?php echo e(app()->getLocale() === 'ar' ? $hotel->name_ar : $hotel->name_en); ?></td>
                            <td class="px-4 py-4 text-slate-600"><?php echo e(\Illuminate\Support\Str::limit(app()->getLocale() === 'ar' ? $hotel->address_ar : $hotel->address_en, 50)); ?></td>
                            <td class="px-4 py-4 text-slate-600"><?php echo e(app()->getLocale() === 'ar' ? ($hotel->province->name_ar ?? '-') : ($hotel->province->name_en ?? '-')); ?></td>
                            <td class="px-4 py-4 text-slate-600"><?php echo e($hotel->rooms_count); ?></td>
                            <td class="px-4 py-4">
                                <?php if($hotel->website_url): ?>
                                    <a href="<?php echo e($hotel->website_url); ?>" target="_blank" rel="noopener" class="text-sky-600 hover:text-sky-700 hover:underline">
                                        <?php echo e(\Illuminate\Support\Str::limit($hotel->website_url, 30)); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="text-slate-400">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-4 text-center">
                                <?php if($hotel->is_active): ?>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-600">
                                        <span class="h-2 w-2 rounded-full bg-emerald-500"></span>
                                        <?php echo e(__('hotel.hotels.badges.active')); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-500">
                                        <span class="h-2 w-2 rounded-full bg-slate-400"></span>
                                        <?php echo e(__('hotel.hotels.badges.inactive')); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-4 text-center">
                                <div class="flex items-center justify-center gap-2">
                                    <a href="<?php echo e(route('hotel.hotel-rooms.index', ['hotel_id' => $hotel->id])); ?>"
                                       class="inline-flex items-center gap-1 rounded-lg bg-blue-500/10 px-3 py-1.5 text-xs font-semibold text-blue-600 hover:bg-blue-500/20">
                                        <i class="fas fa-bed"></i>
                                        <?php echo e(__('hotel.hotels.actions.manage_rooms')); ?>

                                    </a>
                                    <a href="<?php echo e(route('hotel.hotels.edit', $hotel)); ?>"
                                       class="inline-flex items-center gap-1 rounded-lg bg-indigo-500/10 px-3 py-1.5 text-xs font-semibold text-indigo-600 hover:bg-indigo-500/20">
                                        <i class="fas fa-pen-to-square"></i>
                                        <?php echo e(__('hotel.hotels.actions.edit')); ?>

                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-4 py-6 text-center text-sm text-slate-500">
                                <?php echo e(__('hotel.hotels.empty')); ?>

                                <a href="<?php echo e(route('hotel.hotels.create')); ?>"
                                   class="mt-2 inline-block text-indigo-600 hover:text-indigo-700">
                                    <?php echo e(__('hotel.hotels.create_first')); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.hotel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/hotel/hotels/index.blade.php ENDPATH**/ ?>