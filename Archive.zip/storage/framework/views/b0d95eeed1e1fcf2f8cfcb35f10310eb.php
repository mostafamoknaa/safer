<?php $__env->startSection('title', __('admin.conversations.show_title')); ?>
<?php $__env->startSection('page-title', __('admin.conversations.show_heading')); ?>
<?php $__env->startSection('page-subtitle', __('admin.conversations.show_subheading', ['user' => $conversation->user->name])); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid gap-6">
        
        <div class="rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <div class="flex h-16 w-16 items-center justify-center rounded-full bg-indigo-500/10 text-2xl text-indigo-600">
                        <i class="fas fa-user"></i>
                    </div>
                    <div>
                        <h3 class="text-lg font-semibold text-slate-900"><?php echo e($conversation->user->name); ?></h3>
                        <p class="text-sm text-slate-500"><?php echo e($conversation->user->email); ?></p>
                        <?php if($conversation->user->phone): ?>
                            <p class="text-sm text-slate-500"><?php echo e($conversation->user->phone); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="flex items-center gap-3">
                    <?php if($conversation->status === 'open'): ?>
                        <form method="POST" action="<?php echo e(route('admin.conversations.close', $conversation)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit"
                                    class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
                                <i class="fas fa-archive"></i>
                                <?php echo e(__('admin.conversations.actions.close')); ?>

                            </button>
                        </form>
                    <?php else: ?>
                        <form method="POST" action="<?php echo e(route('admin.conversations.reopen', $conversation)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit"
                                    class="inline-flex items-center gap-2 rounded-xl bg-emerald-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-emerald-600">
                                <i class="fas fa-redo"></i>
                                <?php echo e(__('admin.conversations.actions.reopen')); ?>

                            </button>
                        </form>
                    <?php endif; ?>
                    <a href="<?php echo e(route('admin.conversations.index')); ?>"
                       class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
                        <i class="fas fa-arrow-right"></i>
                        <?php echo e(__('admin.conversations.back_to_list')); ?>

                    </a>
                </div>
            </div>
        </div>

        
        <div class="rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur">
            <div id="messagesContainer" class="space-y-4 max-h-[600px] overflow-y-auto mb-6 pb-6">
                <?php $__empty_1 = true; $__currentLoopData = $conversation->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'flex gap-3',
                        'flex-row-reverse' => $message->sender_type === 'admin',
                    ]); ?>">
                        <div class="flex-shrink-0">
                            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'flex h-10 w-10 items-center justify-center rounded-full text-sm font-semibold',
                                'bg-indigo-500 text-white' => $message->sender_type === 'admin',
                                'bg-slate-300 text-slate-700' => $message->sender_type === 'user',
                            ]); ?>">
                                <i class="fas <?php echo e($message->sender_type === 'admin' ? 'fa-user-tie' : 'fa-user'); ?>"></i>
                            </div>
                        </div>
                        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'flex-1 rounded-2xl px-4 py-3 max-w-2xl',
                            'bg-indigo-500 text-white' => $message->sender_type === 'admin',
                            'bg-slate-100 text-slate-800' => $message->sender_type === 'user',
                        ]); ?>">
                            <div class="flex items-center gap-2 mb-1">
                                <span class="text-xs font-semibold opacity-90"><?php echo e($message->sender->name); ?></span>
                                <span class="text-xs opacity-75"><?php echo e($message->created_at->format('Y-m-d H:i')); ?></span>
                            </div>
                            <?php if($message->type === 'file'): ?>
                                <div class="flex items-center gap-3">
                                    <i class="fas fa-file text-xl"></i>
                                    <a href="<?php echo e(Storage::url($message->file_path)); ?>" target="_blank" 
                                       class="hover:underline font-medium">
                                        <?php echo e($message->file_name ?? 'ملف'); ?>

                                    </a>
                                </div>
                            <?php endif; ?>
                            <?php if($message->message): ?>
                                <p class="mt-2 whitespace-pre-wrap"><?php echo e($message->message); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-12 text-slate-500">
                        <i class="fas fa-comments text-4xl mb-3 opacity-50"></i>
                        <p><?php echo e(__('admin.conversations.no_messages')); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            
            <?php if($conversation->status === 'open'): ?>
                <form method="POST" action="<?php echo e(route('admin.conversations.send-message', $conversation)); ?>" 
                      enctype="multipart/form-data"
                      class="border-t border-slate-200 pt-6 mt-6">
                    <?php echo csrf_field(); ?>
                    <div class="grid gap-4">
                        <div class="grid gap-2">
                            <label for="message" class="text-sm font-medium text-slate-600">
                                <?php echo e(__('admin.conversations.form.message')); ?>

                            </label>
                            <textarea id="message" name="message" rows="3"
                                      class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                                      placeholder="<?php echo e(__('admin.conversations.form.message_placeholder')); ?>"></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="grid gap-2">
                            <label for="file" class="text-sm font-medium text-slate-600">
                                <?php echo e(__('admin.conversations.form.file')); ?>

                            </label>
                            <input id="file" name="file" type="file"
                                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                            <p class="text-xs text-slate-400"><?php echo e(__('admin.conversations.form.file_hint')); ?></p>
                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="flex items-center justify-end gap-3">
                            <button type="submit"
                                    class="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-3 text-sm font-semibold text-white shadow-md shadow-indigo-400/40 transition hover:bg-indigo-700">
                                <i class="fas fa-paper-plane"></i>
                                <?php echo e(__('admin.conversations.actions.send')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            <?php else: ?>
                <div class="border-t border-slate-200 pt-6 mt-6 text-center text-slate-500">
                    <p><?php echo e(__('admin.conversations.conversation_closed')); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            // Auto scroll to bottom
            const messagesContainer = document.getElementById('messagesContainer');
            if (messagesContainer) {
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/admin/conversations/show.blade.php ENDPATH**/ ?>