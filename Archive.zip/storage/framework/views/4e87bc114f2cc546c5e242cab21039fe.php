<?php
    $editing = isset($booking);
?>

<div class="grid gap-6">
    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="user_id" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.bookings.form.user')); ?>

            </label>
            <select id="user_id" name="user_id"
                    class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    required>
                <option value=""><?php echo e(__('admin.bookings.form.user')); ?></option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php if(old('user_id', $booking->user_id ?? '') == $user->id): echo 'selected'; endif; ?>>
                        <?php echo e($user->name); ?> (<?php echo e($user->email); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid gap-2">
            <label for="hotel_id" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.bookings.form.hotel')); ?>

            </label>
            <select id="hotel_id" name="hotel_id"
                    class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    required>
                <option value=""><?php echo e(__('admin.bookings.form.hotel')); ?></option>
                <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($hotel->id); ?>" <?php if(old('hotel_id', $booking->hotel_id ?? '') == $hotel->id): echo 'selected'; endif; ?>>
                        <?php echo e(app()->getLocale() === 'ar' ? $hotel->name_ar : $hotel->name_en); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['hotel_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-2">
        <label for="room_id" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.bookings.form.room')); ?>

        </label>
        <select id="room_id" name="room_id"
                class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
            <option value=""><?php echo e(__('admin.bookings.form.room')); ?></option>
            <?php if(isset($rooms) && $rooms->count() > 0): ?>
                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($room->id); ?>" <?php if(old('room_id', ($booking->room_id ?? '')) == $room->id): echo 'selected'; endif; ?>>
                        <?php echo e(number_format($room->price_per_night, 2)); ?> <?php echo e(__('admin.bookings.currency')); ?> - <?php echo e(__('admin.bookings.table.rooms')); ?>: <?php echo e($room->rooms_count); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
        <?php $__errorArgs = ['room_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <p class="text-xs text-slate-400"><?php echo e(__('admin.bookings.form.room_hint')); ?></p>
    </div>

    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="check_in_date" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.bookings.form.check_in_date')); ?>

            </label>
            <input id="check_in_date" name="check_in_date" type="date"
                   value="<?php echo e(old('check_in_date', isset($booking) && $booking->check_in_date ? $booking->check_in_date->format('Y-m-d') : '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['check_in_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid gap-2">
            <label for="check_out_date" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.bookings.form.check_out_date')); ?>

            </label>
            <input id="check_out_date" name="check_out_date" type="date"
                   value="<?php echo e(old('check_out_date', isset($booking) && $booking->check_out_date ? $booking->check_out_date->format('Y-m-d') : '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['check_out_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-4 sm:grid-cols-3">
        <div class="grid gap-2">
            <label for="guests_count" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.bookings.form.guests_count')); ?>

            </label>
            <input id="guests_count" name="guests_count" type="number" min="1"
                   value="<?php echo e(old('guests_count', $booking->guests_count ?? '1')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['guests_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid gap-2">
            <label for="rooms_count" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.bookings.form.rooms_count')); ?>

            </label>
            <input id="rooms_count" name="rooms_count" type="number" min="1"
                   value="<?php echo e(old('rooms_count', $booking->rooms_count ?? '1')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['rooms_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid gap-2">
            <label for="price_per_night" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.bookings.form.price_per_night')); ?>

            </label>
            <input id="price_per_night" name="price_per_night" type="number" step="0.01" min="0"
                   value="<?php echo e(old('price_per_night', $booking->price_per_night ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['price_per_night'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="status" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.bookings.form.status')); ?>

            </label>
            <select id="status" name="status"
                    class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    required>
                <option value="pending" <?php if(old('status', $booking->status ?? 'pending') == 'pending'): echo 'selected'; endif; ?>>
                    <?php echo e(__('admin.bookings.status.pending')); ?>

                </option>
                <option value="confirmed" <?php if(old('status', $booking->status ?? '') == 'confirmed'): echo 'selected'; endif; ?>>
                    <?php echo e(__('admin.bookings.status.confirmed')); ?>

                </option>
                <option value="checked_in" <?php if(old('status', $booking->status ?? '') == 'checked_in'): echo 'selected'; endif; ?>>
                    <?php echo e(__('admin.bookings.status.checked_in')); ?>

                </option>
                <option value="checked_out" <?php if(old('status', $booking->status ?? '') == 'checked_out'): echo 'selected'; endif; ?>>
                    <?php echo e(__('admin.bookings.status.checked_out')); ?>

                </option>
                <option value="cancelled" <?php if(old('status', $booking->status ?? '') == 'cancelled'): echo 'selected'; endif; ?>>
                    <?php echo e(__('admin.bookings.status.cancelled')); ?>

                </option>
            </select>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid gap-2">
            <label class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.bookings.form.total_price')); ?>

            </label>
            <div class="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-600">
                <span id="total_price_display"><?php echo e(number_format(old('total_price', $booking->total_price ?? 0), 2)); ?></span> <?php echo e(__('admin.bookings.currency')); ?>

            </div>
            <input type="hidden" id="nights_count" name="nights_count" value="<?php echo e(old('nights_count', $booking->nights_count ?? 1)); ?>">
        </div>
    </div>

    <div class="grid gap-2">
        <label for="notes" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.bookings.form.notes')); ?>

        </label>
        <textarea id="notes" name="notes" rows="3"
                  class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"><?php echo e(old('notes', $booking->notes ?? '')); ?></textarea>
        <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="grid gap-2">
        <label for="admin_notes" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.bookings.form.admin_notes')); ?>

        </label>
        <textarea id="admin_notes" name="admin_notes" rows="3"
                  class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"><?php echo e(old('admin_notes', $booking->admin_notes ?? '')); ?></textarea>
        <?php $__errorArgs = ['admin_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
        <a href="<?php echo e(route('admin.bookings.index')); ?>"
           class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
            <i class="fas fa-times"></i>
            <?php echo e(__('admin.bookings.actions.cancel')); ?>

        </a>
        <button type="submit"
                class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-slate-400/40 transition hover:bg-slate-700">
            <i class="fas fa-save"></i>
            <?php echo e($editing ? __('admin.bookings.actions.update') : __('admin.bookings.actions.store')); ?>

        </button>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const checkInDate = document.getElementById('check_in_date');
    const checkOutDate = document.getElementById('check_out_date');
    const pricePerNight = document.getElementById('price_per_night');
    const roomsCount = document.getElementById('rooms_count');
    const nightsCount = document.getElementById('nights_count');
    const totalPriceDisplay = document.getElementById('total_price_display');
    const hotelId = document.getElementById('hotel_id');
    const roomId = document.getElementById('room_id');

    function calculateTotal() {
        if (checkInDate.value && checkOutDate.value && pricePerNight.value && roomsCount.value) {
            const checkIn = new Date(checkInDate.value);
            const checkOut = new Date(checkOutDate.value);
            const nights = Math.max(1, Math.ceil((checkOut - checkIn) / (1000 * 60 * 60 * 24)));
            const total = parseFloat(pricePerNight.value) * nights * parseInt(roomsCount.value);
            
            if (nightsCount) nightsCount.value = nights;
            if (totalPriceDisplay) totalPriceDisplay.textContent = total.toFixed(2);
        }
    }

    if (checkInDate) checkInDate.addEventListener('change', calculateTotal);
    if (checkOutDate) checkOutDate.addEventListener('change', calculateTotal);
    if (pricePerNight) pricePerNight.addEventListener('input', calculateTotal);
    if (roomsCount) roomsCount.addEventListener('input', calculateTotal);

    // Load rooms when hotel is selected (for create)
    <?php if(!$editing): ?>
    if (hotelId) {
        hotelId.addEventListener('change', function() {
            const hotelIdValue = this.value;
            if (hotelIdValue) {
                // Load rooms via AJAX or refresh page
                fetch('/admin/hotels/' + hotelIdValue + '/rooms')
                    .then(response => response.json())
                    .then(data => {
                        roomId.innerHTML = '<option value=""><?php echo e(__('admin.bookings.form.room')); ?></option>';
                        data.forEach(room => {
                            const option = document.createElement('option');
                            option.value = room.id;
                            option.textContent = room.price_per_night + ' <?php echo e(__('admin.bookings.currency')); ?>';
                            roomId.appendChild(option);
                        });
                    })
                    .catch(error => console.error('Error loading rooms:', error));
            } else {
                roomId.innerHTML = '<option value=""><?php echo e(__('admin.bookings.form.room')); ?></option>';
            }
        });
    }
    <?php endif; ?>
});
</script>
<?php $__env->stopPush(); ?>

<?php /**PATH /Volumes/D/project/safer/resources/views/admin/bookings/_form.blade.php ENDPATH**/ ?>