<?php $__env->startSection('title', __('admin.contact_links.create_title')); ?>
<?php $__env->startSection('page-title', __('admin.contact_links.create_heading')); ?>
<?php $__env->startSection('page-subtitle', __('admin.contact_links.create_subheading')); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('admin.contact-links.store')); ?>"
          class="rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('admin.contact-links._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/admin/contact-links/create.blade.php ENDPATH**/ ?>