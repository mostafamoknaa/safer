<?php
    $editing = isset($policy);
?>

<div class="grid gap-6">
    <div class="grid gap-2">
        <label for="title_ar" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.policies.form.title_ar')); ?>

        </label>
        <input id="title_ar" name="title_ar" type="text"
               value="<?php echo e(old('title_ar', $policy->title_ar ?? '')); ?>"
               class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
               required>
        <?php $__errorArgs = ['title_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="grid gap-2">
        <label for="title_en" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.policies.form.title_en')); ?>

        </label>
        <input id="title_en" name="title_en" type="text"
               value="<?php echo e(old('title_en', $policy->title_en ?? '')); ?>"
               class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
               required>
        <?php $__errorArgs = ['title_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="grid gap-2 sm:grid-cols-2 sm:gap-4">
        <div class="grid gap-2">
            <label for="slug" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.policies.form.slug')); ?>

            </label>
            <input id="slug" name="slug" type="text"
                   value="<?php echo e(old('slug', $policy->slug ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   placeholder="privacy-policy">
            <p class="text-xs text-slate-400"><?php echo e(__('admin.policies.form.slug_hint')); ?></p>
            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <label class="inline-flex items-center gap-2 text-sm font-medium text-slate-600 mt-8 sm:mt-0">
            <input type="checkbox" name="is_active" value="1"
                   <?php if(old('is_active', $policy->is_active ?? true)): echo 'checked'; endif; ?>
                   class="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
            <?php echo e(__('admin.policies.form.is_active')); ?>

        </label>
    </div>

    <div class="grid gap-2">
        <label for="body_ar" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.policies.form.body_ar')); ?>

        </label>
        <input id="body_ar" name="body_ar" type="hidden" value="<?php echo e(old('body_ar', $policy->body_ar ?? '')); ?>">
        <trix-editor input="body_ar" dir="rtl" class="bg-white"></trix-editor>
        <?php $__errorArgs = ['body_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="grid gap-2">
        <label for="body_en" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.policies.form.body_en')); ?>

        </label>
        <input id="body_en" name="body_en" type="hidden" value="<?php echo e(old('body_en', $policy->body_en ?? '')); ?>">
        <trix-editor input="body_en" class="bg-white" dir="ltr"></trix-editor>
        <?php $__errorArgs = ['body_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="flex items-center justify-end gap-3">
        <a href="<?php echo e(route('admin.policies.index')); ?>"
           class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
            <?php echo e(__('admin.policies.actions.cancel')); ?>

        </a>
        <button type="submit"
                class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-slate-400/40 transition hover:bg-slate-700">
            <i class="fas fa-floppy-disk"></i>
            <?php echo e($editing ? __('admin.policies.actions.update') : __('admin.policies.actions.store')); ?>

        </button>
    </div>
</div>

<?php /**PATH /Volumes/D/project/safer/resources/views/admin/policies/_form.blade.php ENDPATH**/ ?>