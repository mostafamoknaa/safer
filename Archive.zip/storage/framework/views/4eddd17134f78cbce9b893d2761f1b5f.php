<?php
    $editing = isset($privateCar);
?>

<div class="grid gap-6">
    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="name_ar" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.private_cars.form.name_ar')); ?>

            </label>
            <input id="name_ar" name="name_ar" type="text"
                   value="<?php echo e(old('name_ar', $privateCar->name_ar ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   dir="rtl"
                   required>
            <?php $__errorArgs = ['name_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid gap-2">
            <label for="name_en" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.private_cars.form.name_en')); ?>

            </label>
            <input id="name_en" name="name_en" type="text"
                   value="<?php echo e(old('name_en', $privateCar->name_en ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   dir="ltr"
                   required>
            <?php $__errorArgs = ['name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="price" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.private_cars.form.price')); ?>

            </label>
            <input id="price" name="price" type="number" step="0.01" min="0"
                   value="<?php echo e(old('price', $privateCar->price ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid gap-2">
            <label for="seats_count" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.private_cars.form.seats_count')); ?>

            </label>
            <input id="seats_count" name="seats_count" type="number" min="1"
                   value="<?php echo e(old('seats_count', $privateCar->seats_count ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['seats_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-2">
        <label for="image" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.private_cars.form.image')); ?>

        </label>
        <input id="image" name="image" type="file" accept="image/*"
               class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php if($editing && $privateCar->image): ?>
            <div class="mt-2">
                <img src="<?php echo e(asset('storage/' . $privateCar->image)); ?>" alt="<?php echo e($privateCar->name); ?>" class="h-32 w-32 rounded-lg object-cover">
            </div>
        <?php endif; ?>
    </div>

    <div class="grid gap-4 sm:grid-cols-3">
        <div class="grid gap-2">
            <label for="max_speed" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.private_cars.form.max_speed')); ?>

            </label>
            <input id="max_speed" name="max_speed" type="number" min="0"
                   value="<?php echo e(old('max_speed', $privateCar->max_speed ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
            <?php $__errorArgs = ['max_speed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid gap-2">
            <label for="acceleration" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.private_cars.form.acceleration')); ?>

            </label>
            <input id="acceleration" name="acceleration" type="number" step="0.01" min="0"
                   value="<?php echo e(old('acceleration', $privateCar->acceleration ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
            <?php $__errorArgs = ['acceleration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid gap-2">
            <label for="power" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.private_cars.form.power')); ?>

            </label>
            <input id="power" name="power" type="number" min="0"
                   value="<?php echo e(old('power', $privateCar->power ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
            <?php $__errorArgs = ['power'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="notes_ar" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.private_cars.form.notes_ar')); ?>

            </label>
            <textarea id="notes_ar" name="notes_ar" rows="3"
                      class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      dir="rtl"><?php echo e(old('notes_ar', $privateCar->notes_ar ?? '')); ?></textarea>
            <?php $__errorArgs = ['notes_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="grid gap-2">
            <label for="notes_en" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.private_cars.form.notes_en')); ?>

            </label>
            <textarea id="notes_en" name="notes_en" rows="3"
                      class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      dir="ltr"><?php echo e(old('notes_en', $privateCar->notes_en ?? '')); ?></textarea>
            <?php $__errorArgs = ['notes_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-2">
        <label class="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" name="is_active" value="1"
                   <?php if(old('is_active', $privateCar->is_active ?? true)): echo 'checked'; endif; ?>
                   class="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
            <span class="text-sm font-medium text-slate-600"><?php echo e(__('admin.private_cars.form.is_active')); ?></span>
        </label>
    </div>

    <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
        <a href="<?php echo e(route('admin.private-cars.index')); ?>"
           class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
            <i class="fas fa-times"></i>
            <?php echo e(__('admin.private_cars.actions.cancel')); ?>

        </a>
        <button type="submit"
                class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-slate-400/40 transition hover:bg-slate-700">
            <i class="fas fa-save"></i>
            <?php echo e($editing ? __('admin.private_cars.actions.update') : __('admin.private_cars.actions.store')); ?>

        </button>
    </div>
</div>

<?php /**PATH /Volumes/D/project/safer/resources/views/admin/private-cars/_form.blade.php ENDPATH**/ ?>