<?php $__env->startSection('title', __('admin.faq.page_title')); ?>
<?php $__env->startSection('page-title', __('admin.faq.heading')); ?>
<?php $__env->startSection('page-subtitle', __('admin.faq.intro')); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $items = __('admin.faq.items');
    ?>

    <div class="grid gap-6 lg:grid-cols-2">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="rounded-3xl border border-slate-200/80 bg-white/80 p-6 shadow-lg shadow-slate-100/60 backdrop-blur">
                <h2 class="text-lg font-semibold text-slate-900"><?php echo e($item['question']); ?></h2>
                <p class="mt-4 text-sm leading-relaxed text-slate-600"><?php echo e($item['answer']); ?></p>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-8 flex flex-col items-center justify-center gap-3 rounded-3xl border border-sky-200/70 bg-sky-50/70 px-6 py-6 text-center shadow-sm shadow-sky-200/40">
        <span class="inline-flex h-12 w-12 items-center justify-center rounded-full bg-sky-500/10 text-sky-500 text-xl">
            <i class="fas fa-message"></i>
        </span>
        <p class="text-sm font-medium text-slate-700"><?php echo e(__('admin.faq.cta')); ?></p>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/admin/pages/faq.blade.php ENDPATH**/ ?>