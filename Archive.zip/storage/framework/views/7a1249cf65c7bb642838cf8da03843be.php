<?php
    $editing = isset($hotelRoom);
?>

<div class="grid gap-6">
    <?php if($editing): ?>
        
        <div class="grid gap-2">
            <label class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.hotel_rooms.form.hotel')); ?>

            </label>
            <div class="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-600">
                <div class="flex items-center gap-2">
                    <i class="fas fa-hotel text-slate-400"></i>
                    <span><?php echo e(app()->getLocale() === 'ar' ? $hotelRoom->hotel->name_ar : $hotelRoom->hotel->name_en); ?></span>
                </div>
            </div>
            <input type="hidden" name="hotel_id" value="<?php echo e($hotelRoom->hotel_id); ?>">
        </div>
    <?php else: ?>
        
        <div class="grid gap-2">
            <label for="hotel_id" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.hotel_rooms.form.hotel')); ?>

            </label>
            <select id="hotel_id" name="hotel_id"
                    class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    required>
                <option value=""><?php echo e(__('admin.hotel_rooms.form.hotel')); ?></option>
                <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($hotel->id); ?>" <?php if(old('hotel_id', $selectedHotelId ?? '') == $hotel->id): echo 'selected'; endif; ?>>
                        <?php echo e(app()->getLocale() === 'ar' ? $hotel->name_ar : $hotel->name_en); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['hotel_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    <?php endif; ?>

    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="price_per_night" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.hotel_rooms.form.price_per_night')); ?>

            </label>
            <input id="price_per_night" name="price_per_night" type="number" step="0.01" min="0"
                   value="<?php echo e(old('price_per_night', $hotelRoom->price_per_night ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['price_per_night'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="grid gap-2">
            <label for="beds_count" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.hotel_rooms.form.beds_count')); ?>

            </label>
            <input id="beds_count" name="beds_count" type="number" min="1"
                   value="<?php echo e(old('beds_count', $hotelRoom->beds_count ?? '1')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['beds_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="bathrooms_count" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.hotel_rooms.form.bathrooms_count')); ?>

            </label>
            <input id="bathrooms_count" name="bathrooms_count" type="number" min="1"
                   value="<?php echo e(old('bathrooms_count', $hotelRoom->bathrooms_count ?? '1')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['bathrooms_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="grid gap-2">
            <label for="rooms_count" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.hotel_rooms.form.rooms_count')); ?>

            </label>
            <input id="rooms_count" name="rooms_count" type="number" min="1"
                   value="<?php echo e(old('rooms_count', $hotelRoom->rooms_count ?? '1')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   required>
            <?php $__errorArgs = ['rooms_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-2">
        <label for="images" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.hotel_rooms.form.images')); ?>

        </label>
        <input id="images" name="images[]" type="file" multiple accept="image/*"
               class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
        <p class="text-xs text-slate-400"><?php echo e(__('admin.hotel_rooms.form.images_hint')); ?></p>
        <?php $__errorArgs = ['images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <?php if($editing && $hotelRoom->media->count() > 0): ?>
        <div class="grid gap-4">
            <label class="text-sm font-medium text-slate-600">الصور الحالية</label>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <?php $__currentLoopData = $hotelRoom->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="relative group">
                        <img src="<?php echo e(Storage::url($media->file_path)); ?>" alt="Room Image" class="w-full h-32 object-cover rounded-lg">
                        <label class="absolute top-2 right-2 flex items-center gap-1">
                            <input type="checkbox" name="delete_media[]" value="<?php echo e($media->id); ?>" class="rounded border-slate-300 text-rose-600 focus:ring-rose-500">
                            <span class="text-xs text-white bg-rose-500 px-2 py-1 rounded">حذف</span>
                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="flex items-center gap-3">
        <label class="inline-flex items-center gap-2 text-sm font-medium text-slate-600">
            <input type="checkbox" name="is_active" value="1"
                   <?php if(old('is_active', $hotelRoom->is_active ?? true)): echo 'checked'; endif; ?>
                   class="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
            <?php echo e(__('admin.hotel_rooms.form.is_active')); ?>

        </label>
    </div>

    <div class="flex items-center justify-end gap-3">
        <a href="<?php echo e(route('admin.hotel-rooms.index', request()->has('hotel_id') ? ['hotel_id' => request()->hotel_id] : [])); ?>"
           class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
            <?php echo e(__('admin.hotel_rooms.actions.cancel')); ?>

        </a>
        <button type="submit"
                class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-slate-400/40 transition hover:bg-slate-700">
            <i class="fas fa-floppy-disk"></i>
            <?php echo e($editing ? __('admin.hotel_rooms.actions.update') : __('admin.hotel_rooms.actions.store')); ?>

        </button>
    </div>
</div>

<?php /**PATH /Volumes/D/project/safer/resources/views/admin/hotel-rooms/_form.blade.php ENDPATH**/ ?>