<?php $__env->startSection('title', __('admin.contact.page_title')); ?>
<?php $__env->startSection('page-title', __('admin.contact.heading')); ?>
<?php $__env->startSection('page-subtitle', __('admin.contact.intro')); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid gap-6 lg:grid-cols-3">
        <?php
            $cards = __('admin.contact.cards');
        ?>
        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="rounded-2xl border border-slate-200/80 bg-white/80 p-6 shadow-lg shadow-slate-100/60 backdrop-blur">
                <div class="flex items-center justify-between">
                    <h2 class="text-lg font-semibold text-slate-900"><?php echo e($card['title']); ?></h2>
                    <span class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-sky-500/10 text-sky-500">
                        <i class="fas fa-comments"></i>
                    </span>
                </div>
                <p class="mt-3 text-sm text-slate-600 leading-relaxed"><?php echo e($card['description']); ?></p>
                <dl class="mt-4 space-y-2 text-sm">
                    <?php if(isset($card['email'])): ?>
                        <div class="flex items-center gap-3 rounded-xl bg-sky-50/70 px-4 py-2 text-sky-700">
                            <span class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white text-sky-600">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <div>
                                <dt class="font-medium"><?php echo e(__('admin.contact.labels.email')); ?></dt>
                                <dd class="text-sky-700/80">
                                    <a href="mailto:<?php echo e($card['email']); ?>" class="hover:underline"><?php echo e($card['email']); ?></a>
                                </dd>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($card['phone'])): ?>
                        <div class="flex items-center gap-3 rounded-xl bg-emerald-50/70 px-4 py-2 text-emerald-700">
                            <span class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white text-emerald-600">
                                <i class="fas fa-phone"></i>
                            </span>
                            <div>
                                <dt class="font-medium"><?php echo e(__('admin.contact.labels.phone')); ?></dt>
                                <dd>
                                    <a href="tel:<?php echo e(preg_replace('/\s+/', '', $card['phone'])); ?>" class="hover:underline">
                                        <?php echo e($card['phone']); ?>

                                    </a>
                                </dd>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($card['whatsapp'])): ?>
                        <div class="flex items-center gap-3 rounded-xl bg-emerald-50/70 px-4 py-2 text-emerald-700">
                            <span class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white text-emerald-600">
                                <i class="fab fa-whatsapp"></i>
                            </span>
                            <div>
                                <dt class="font-medium"><?php echo e(__('admin.contact.labels.whatsapp')); ?></dt>
                                <dd>
                                    <a href="https://wa.me/<?php echo e(preg_replace('/\D+/', '', $card['whatsapp'])); ?>" class="hover:underline" target="_blank" rel="noopener">
                                        <?php echo e($card['whatsapp']); ?>

                                    </a>
                                </dd>
                            </div>
                        </div>
                    <?php endif; ?>
                </dl>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <section class="mt-10 rounded-3xl border border-slate-200/80 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8 text-white shadow-xl">
        <div class="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight"><?php echo e(__('admin.contact.social.title')); ?></h2>
                <p class="mt-2 max-w-xl text-sm text-slate-100/70"><?php echo e(__('admin.contact.social.subtitle')); ?></p>
                <div class="mt-6 flex flex-wrap gap-3">
                    <?php
                        $socialItems = __('admin.contact.social.items');
                        $links = [
                            'twitter' => 'https://twitter.com/saferhotels',
                            'instagram' => 'https://instagram.com/safer.hotels',
                            'linkedin' => 'https://linkedin.com/company/safer-hotels',
                            'youtube' => 'https://youtube.com/@saferhotels',
                        ];
                        $icons = [
                            'twitter' => 'fab fa-x-twitter',
                            'instagram' => 'fab fa-instagram',
                            'linkedin' => 'fab fa-linkedin-in',
                            'youtube' => 'fab fa-youtube',
                        ];
                    ?>
                    <?php $__currentLoopData = $socialItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($links[$key] ?? '#'); ?>" target="_blank" rel="noopener"
                           class="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-medium backdrop-blur transition hover:bg-white/20">
                            <i class="<?php echo e($icons[$key] ?? 'fas fa-link'); ?>"></i>
                            <span><?php echo e($label); ?></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="rounded-2xl bg-white/10 p-6 backdrop-blur">
                <h3 class="text-sm font-semibold uppercase tracking-widest text-sky-100"><?php echo e(__('admin.contact.labels.website_title')); ?></h3>
                <p class="mt-3 text-sm text-sky-100/80"><?php echo e(__('admin.contact.labels.website_hint')); ?></p>
                <a href="https://safer-hotels.com" target="_blank" rel="noopener"
                   class="mt-5 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-slate-900 shadow-lg shadow-sky-900/30 transition hover:bg-slate-100">
                    <i class="fas fa-globe"></i>
                    <?php echo e(__('admin.contact.social.website')); ?>

                </a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/admin/pages/contact.blade.php ENDPATH**/ ?>