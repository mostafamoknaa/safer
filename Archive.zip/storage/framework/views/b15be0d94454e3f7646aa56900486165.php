<?php
    $editing = isset($hotel);
?>

<?php if($editing): ?>
    <?php echo method_field('PUT'); ?>
<?php endif; ?>

<div class="grid gap-6">
    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="name_ar" class="text-sm font-medium text-slate-600">
                <?php echo e(__('hotel.hotels.form.name')); ?> - <?php echo e(__('Arabic', [], 'ar')); ?>

            </label>
            <input id="name_ar" name="name_ar" type="text"
                   value="<?php echo e(old('name_ar', $hotel->name_ar ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   dir="rtl"
                   required>
            <?php $__errorArgs = ['name_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="grid gap-2">
            <label for="name_en" class="text-sm font-medium text-slate-600">
                <?php echo e(__('hotel.hotels.form.name')); ?> - <?php echo e(__('English', [], 'en')); ?>

            </label>
            <input id="name_en" name="name_en" type="text"
                   value="<?php echo e(old('name_en', $hotel->name_en ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   dir="ltr"
                   required>
            <?php $__errorArgs = ['name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="province_id" class="text-sm font-medium text-slate-600">
                <?php echo e(__('hotel.hotels.form.province')); ?>

            </label>
            <select id="province_id" name="province_id"
                    class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    required>
                <option value=""><?php echo e(__('hotel.hotels.form.province')); ?></option>
                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($province->id); ?>" <?php if(old('province_id', $hotel->province_id ?? '') == $province->id): echo 'selected'; endif; ?>>
                        <?php echo e(app()->getLocale() === 'ar' ? $province->name_ar : $province->name_en); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p class="text-xs text-slate-400"><?php echo e(__('hotel.hotels.form.province_hint')); ?></p>
            <?php $__errorArgs = ['province_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="grid gap-2">
            <label for="website_url" class="text-sm font-medium text-slate-600">
                <?php echo e(__('hotel.hotels.form.website_url')); ?>

            </label>
            <input id="website_url" name="website_url" type="url"
                   value="<?php echo e(old('website_url', $hotel->website_url ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                   dir="ltr">
            <?php $__errorArgs = ['website_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="address_ar" class="text-sm font-medium text-slate-600">
                <?php echo e(__('hotel.hotels.form.address')); ?> - <?php echo e(__('Arabic', [], 'ar')); ?>

            </label>
            <textarea id="address_ar" name="address_ar" rows="2"
                      class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      dir="rtl"
                      required><?php echo e(old('address_ar', $hotel->address_ar ?? '')); ?></textarea>
            <?php $__errorArgs = ['address_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="grid gap-2">
            <label for="address_en" class="text-sm font-medium text-slate-600">
                <?php echo e(__('hotel.hotels.form.address')); ?> - <?php echo e(__('English', [], 'en')); ?>

            </label>
            <textarea id="address_en" name="address_en" rows="2"
                      class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      dir="ltr"
                      required><?php echo e(old('address_en', $hotel->address_en ?? '')); ?></textarea>
            <?php $__errorArgs = ['address_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="about_info_ar" class="text-sm font-medium text-slate-600">
                <?php echo e(__('hotel.hotels.form.about_info')); ?> - <?php echo e(__('Arabic', [], 'ar')); ?>

            </label>
            <textarea id="about_info_ar" name="about_info_ar" rows="4"
                      class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      dir="rtl"><?php echo e(old('about_info_ar', $hotel->about_info_ar ?? '')); ?></textarea>
            <p class="text-xs text-slate-400"><?php echo e(__('hotel.hotels.form.about_info_hint')); ?></p>
            <?php $__errorArgs = ['about_info_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="grid gap-2">
            <label for="about_info_en" class="text-sm font-medium text-slate-600">
                <?php echo e(__('hotel.hotels.form.about_info')); ?> - <?php echo e(__('English', [], 'en')); ?>

            </label>
            <textarea id="about_info_en" name="about_info_en" rows="4"
                      class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      dir="ltr"><?php echo e(old('about_info_en', $hotel->about_info_en ?? '')); ?></textarea>
            <p class="text-xs text-slate-400"><?php echo e(__('hotel.hotels.form.about_info_hint')); ?></p>
            <?php $__errorArgs = ['about_info_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-4 sm:grid-cols-2">
        <div class="grid gap-2">
            <label for="images" class="text-sm font-medium text-slate-600">
                <?php echo e(__('hotel.hotels.form.images')); ?>

            </label>
            <input id="images" name="images[]" type="file" multiple accept="image/*"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
            <p class="text-xs text-slate-400"><?php echo e(__('hotel.hotels.form.images_hint')); ?></p>
            <?php $__errorArgs = ['images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="grid gap-2">
            <label for="videos" class="text-sm font-medium text-slate-600">
                <?php echo e(__('hotel.hotels.form.videos')); ?>

            </label>
            <input id="videos" name="videos[]" type="file" multiple accept="video/*"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
            <p class="text-xs text-slate-400"><?php echo e(__('hotel.hotels.form.videos_hint')); ?></p>
            <?php $__errorArgs = ['videos.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <?php if($editing && $hotel->media->count() > 0): ?>
        <div class="grid gap-4">
            <label class="text-sm font-medium text-slate-600">الوسائط الحالية</label>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <?php $__currentLoopData = $hotel->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="relative group">
                        <?php if($media->type === 'image'): ?>
                            <img src="<?php echo e(Storage::url($media->file_path)); ?>" alt="Media" class="w-full h-32 object-cover rounded-lg">
                        <?php else: ?>
                            <video src="<?php echo e(Storage::url($media->file_path)); ?>" class="w-full h-32 object-cover rounded-lg" controls></video>
                        <?php endif; ?>
                        <label class="absolute top-2 right-2 flex items-center gap-1">
                            <input type="checkbox" name="delete_media[]" value="<?php echo e($media->id); ?>" class="rounded border-slate-300 text-rose-600 focus:ring-rose-500">
                            <span class="text-xs text-white bg-rose-500 px-2 py-1 rounded">حذف</span>
                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="flex items-center gap-3">
        <label class="inline-flex items-center gap-2 text-sm font-medium text-slate-600">
            <input type="checkbox" name="is_active" value="1"
                   <?php if(old('is_active', $hotel->is_active ?? true)): echo 'checked'; endif; ?>
                   class="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
            <?php echo e(__('hotel.hotels.form.is_active')); ?>

        </label>
    </div>

    <div class="flex items-center justify-end gap-3">
        <a href="<?php echo e(route('hotel.hotels.index')); ?>"
           class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
            <?php echo e(__('hotel.hotels.actions.cancel')); ?>

        </a>
        <button type="submit"
                class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-slate-400/40 transition hover:bg-slate-700">
            <i class="fas fa-floppy-disk"></i>
            <?php echo e($editing ? __('hotel.hotels.actions.update') : __('hotel.hotels.actions.store')); ?>

        </button>
    </div>
</div>
<?php /**PATH /Volumes/D/project/safer/resources/views/hotel/hotels/_form.blade.php ENDPATH**/ ?>