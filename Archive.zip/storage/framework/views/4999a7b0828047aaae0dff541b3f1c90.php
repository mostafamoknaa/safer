<?php $__env->startSection('title', __('admin.reports.bookings.page_title')); ?>
<?php $__env->startSection('page-title', __('admin.reports.bookings.heading')); ?>
<?php $__env->startSection('page-subtitle', __('admin.reports.bookings.subheading')); ?>

<?php $__env->startSection('content'); ?>
    <div class="rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-lg font-semibold text-slate-900"><?php echo e(__('admin.reports.bookings.heading')); ?></h2>
                <p class="text-sm text-slate-500"><?php echo e(__('admin.reports.bookings.subheading')); ?></p>
            </div>
            <div class="flex flex-wrap items-center gap-3">
                <form method="GET" action="<?php echo e(route('admin.reports.bookings')); ?>">
                    <?php $__currentLoopData = request()->except('export'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button type="submit" name="export" value="csv"
                            class="inline-flex items-center gap-2 rounded-xl bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-700 shadow-sm hover:bg-emerald-100">
                        <i class="fas fa-file-csv"></i>
                        <?php echo e(__('admin.reports.bookings.actions.download_csv')); ?>

                    </button>
                </form>
            </div>
        </div>

        
        <div class="mt-4 flex flex-wrap gap-2 text-xs">
            <a href="<?php echo e(route('admin.reports.bookings')); ?>" class="inline-flex items-center gap-1 rounded-full bg-slate-900 px-3 py-1.5 font-semibold text-white">
                <i class="fas fa-calendar-check"></i> <?php echo e(__('admin.reports.nav.bookings')); ?>

            </a>
            <a href="<?php echo e(route('admin.reports.payments')); ?>" class="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1.5 font-semibold text-slate-700 hover:bg-slate-200">
                <i class="fas fa-credit-card"></i> <?php echo e(__('admin.reports.nav.payments')); ?>

            </a>
            <a href="<?php echo e(route('admin.reports.services')); ?>" class="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1.5 font-semibold text-slate-700 hover:bg-slate-200">
                <i class="fas fa-clipboard-list"></i> <?php echo e(__('admin.reports.nav.services')); ?>

            </a>
            <a href="<?php echo e(route('admin.reports.events')); ?>" class="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1.5 font-semibold text-slate-700 hover:bg-slate-200">
                <i class="fas fa-calendar-alt"></i> <?php echo e(__('admin.reports.nav.events')); ?>

            </a>
        </div>

        
        <form method="GET" action="<?php echo e(route('admin.reports.bookings')); ?>" class="mt-6 space-y-4">
            <div class="grid gap-4 md:grid-cols-5">
                <div class="grid gap-2">
                    <label for="from_date" class="text-xs font-medium text-slate-500">
                        <?php echo e(__('admin.reports.bookings.filters.from_date')); ?>

                    </label>
                    <input id="from_date" name="from_date" type="date"
                           value="<?php echo e(request('from_date')); ?>"
                           class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                </div>

                <div class="grid gap-2">
                    <label for="to_date" class="text-xs font-medium text-slate-500">
                        <?php echo e(__('admin.reports.bookings.filters.to_date')); ?>

                    </label>
                    <input id="to_date" name="to_date" type="date"
                           value="<?php echo e(request('to_date')); ?>"
                           class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                </div>

                <div class="grid gap-2">
                    <label for="status" class="text-xs font-medium text-slate-500">
                        <?php echo e(__('admin.reports.bookings.filters.status')); ?>

                    </label>
                    <select id="status" name="status"
                            class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                        <option value=""><?php echo e(__('admin.reports.bookings.filters.all_statuses')); ?></option>
                        <option value="pending" <?php if(request('status') === 'pending'): echo 'selected'; endif; ?>><?php echo e(__('admin.bookings.badges.pending')); ?></option>
                        <option value="confirmed" <?php if(request('status') === 'confirmed'): echo 'selected'; endif; ?>><?php echo e(__('admin.bookings.badges.confirmed')); ?></option>
                        <option value="completed" <?php if(request('status') === 'completed'): echo 'selected'; endif; ?>><?php echo e(__('admin.bookings.badges.completed')); ?></option>
                        <option value="cancelled" <?php if(request('status') === 'cancelled'): echo 'selected'; endif; ?>><?php echo e(__('admin.bookings.badges.cancelled')); ?></option>
                    </select>
                </div>

                <div class="grid gap-2">
                    <label for="hotel_id" class="text-xs font-medium text-slate-500">
                        <?php echo e(__('admin.reports.bookings.filters.hotel')); ?>

                    </label>
                    <select id="hotel_id" name="hotel_id"
                            class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                        <option value=""><?php echo e(__('admin.reports.bookings.filters.all_hotels')); ?></option>
                        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($hotel->id); ?>" <?php if(request('hotel_id') == $hotel->id): echo 'selected'; endif; ?>>
                                <?php echo e(app()->getLocale() === 'ar' ? $hotel->name_ar : $hotel->name_en); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="grid gap-2">
                    <label for="user_id" class="text-xs font-medium text-slate-500">
                        <?php echo e(__('admin.reports.bookings.filters.user')); ?>

                    </label>
                    <select id="user_id" name="user_id"
                            class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                        <option value=""><?php echo e(__('admin.reports.bookings.filters.all_users')); ?></option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php if(request('user_id') == $user->id): echo 'selected'; endif; ?>>
                                <?php echo e($user->name); ?> (<?php echo e($user->email); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="flex items-center justify-end gap-3">
                <a href="<?php echo e(route('admin.reports.bookings')); ?>"
                   class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
                    <i class="fas fa-rotate"></i>
                    <?php echo e(__('admin.reports.bookings.actions.reset')); ?>

                </a>
                <button type="submit"
                        class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-slate-400/40 transition hover:bg-slate-700">
                    <i class="fas fa-search"></i>
                    <?php echo e(__('admin.reports.bookings.actions.filter')); ?>

                </button>
            </div>
        </form>

        
        <div class="mt-6 overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200 text-right text-sm">
                <thead class="bg-slate-50 text-xs font-medium uppercase tracking-wider text-slate-500">
                    <tr>
                        <th class="px-4 py-3"><?php echo e(__('admin.bookings.table.reference')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.bookings.table.user')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.bookings.table.hotel')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.bookings.table.room')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.bookings.table.check_in_date')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.bookings.table.check_out_date')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.bookings.table.status')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.bookings.table.total_price')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.bookings.table.created_at')); ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 bg-white">
                    <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-4 py-3 font-mono text-xs text-slate-600">
                                <?php echo e($booking->booking_reference); ?>

                            </td>
                            <td class="px-4 py-3 text-slate-800">
                                <?php echo e($booking->user?->name); ?>

                            </td>
                            <td class="px-4 py-3 text-slate-700">
                                <?php echo e($booking->hotel ? (app()->getLocale() === 'ar' ? $booking->hotel->name_ar : $booking->hotel->name_en) : '-'); ?>

                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                <?php echo e($booking->room_id ?? '-'); ?>

                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                <?php echo e(optional($booking->check_in_date)->format('Y-m-d')); ?>

                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                <?php echo e(optional($booking->check_out_date)->format('Y-m-d')); ?>

                            </td>
                            <td class="px-4 py-3">
                                <?php echo $__env->make('admin.bookings._status_badge', ['status' => $booking->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </td>
                            <td class="px-4 py-3 font-semibold text-slate-900">
                                <?php echo e(number_format($booking->total_price, 2)); ?> <?php echo e(__('admin.bookings.currency')); ?>

                            </td>
                            <td class="px-4 py-3 text-xs text-slate-500">
                                <?php echo e(optional($booking->created_at)->format('Y-m-d H:i')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="px-4 py-6 text-center text-sm text-slate-500">
                                <?php echo e(__('admin.reports.bookings.empty')); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-6">
            <?php echo e($bookings->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/admin/reports/bookings.blade.php ENDPATH**/ ?>