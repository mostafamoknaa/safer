<?php $__env->startSection('title', __('admin.trips.page_title')); ?>
<?php $__env->startSection('page-title', __('admin.trips.heading')); ?>
<?php $__env->startSection('page-subtitle', __('admin.trips.subheading')); ?>

<?php $__env->startSection('content'); ?>
    <div class="rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-lg font-semibold text-slate-900"><?php echo e(__('admin.trips.heading')); ?></h2>
                <p class="text-sm text-slate-500"><?php echo e(__('admin.trips.subheading')); ?></p>
            </div>
            <a href="<?php echo e(route('admin.trips.create')); ?>"
               class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-slate-400/40 transition hover:bg-slate-700">
                <i class="fas fa-plus"></i>
                <?php echo e(__('admin.trips.actions.create')); ?>

            </a>
        </div>

        
        <form method="GET" action="<?php echo e(route('admin.trips.index')); ?>" class="mt-6 space-y-4">
            <div class="grid gap-4 sm:grid-cols-3">
                <input type="date" name="date" value="<?php echo e(request('date')); ?>"
                       class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                
                <select name="bus_id" class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                    <option value=""><?php echo e(__('admin.buses.heading')); ?></option>
                    <?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bus->id); ?>" <?php echo e(request('bus_id') == $bus->id ? 'selected' : ''); ?>>
                            <?php echo e(app()->getLocale() === 'ar' ? $bus->name_ar : $bus->name_en); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <button type="submit"
                        class="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-slate-700">
                    <i class="fas fa-search"></i>
                    <?php echo e(__('admin.trips.search')); ?>

                </button>
            </div>
        </form>

        <div class="mt-6 overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200 text-right text-sm">
                <thead class="bg-slate-50 text-xs font-medium uppercase tracking-wider text-slate-500">
                    <tr>
                        <th class="px-4 py-3"><?php echo e(__('admin.trips.table.departure')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.trips.table.arrival')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.trips.table.bus')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.trips.table.date')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.trips.table.time')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.trips.table.duration')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.trips.table.price')); ?></th>
                        <th class="px-4 py-3 text-center"><?php echo e(__('admin.trips.table.status')); ?></th>
                        <th class="px-4 py-3 text-center"><?php echo e(__('admin.trips.table.actions')); ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 bg-white">
                    <?php $__empty_1 = true; $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-4 py-4 text-slate-800">
                                <?php echo e(app()->getLocale() === 'ar' ? $trip->departure_location_ar : $trip->departure_location_en); ?>

                            </td>
                            <td class="px-4 py-4 text-slate-800">
                                <?php echo e(app()->getLocale() === 'ar' ? $trip->arrival_location_ar : $trip->arrival_location_en); ?>

                            </td>
                            <td class="px-4 py-4 text-slate-600">
                                <?php echo e(app()->getLocale() === 'ar' ? $trip->bus->name_ar : $trip->bus->name_en); ?>

                            </td>
                            <td class="px-4 py-4 text-slate-600"><?php echo e($trip->trip_date->format('Y-m-d')); ?></td>
                            <td class="px-4 py-4 text-slate-600"><?php echo e($trip->trip_time); ?></td>
                            <td class="px-4 py-4 text-slate-600"><?php echo e($trip->duration_minutes); ?> <?php echo e(__('admin.trips.duration_unit')); ?></td>
                            <td class="px-4 py-4 font-semibold text-slate-800"><?php echo e(number_format($trip->price, 2)); ?> <?php echo e(__('admin.trips.currency')); ?></td>
                            <td class="px-4 py-4 text-center">
                                <?php if($trip->is_active): ?>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-600">
                                        <span class="h-2 w-2 rounded-full bg-emerald-500"></span>
                                        <?php echo e(__('admin.hotels.badges.active')); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-500">
                                        <span class="h-2 w-2 rounded-full bg-slate-400"></span>
                                        <?php echo e(__('admin.hotels.badges.inactive')); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-4 text-center">
                                <div class="flex items-center justify-center gap-2">
                                    <a href="<?php echo e(route('admin.trips.edit', $trip)); ?>"
                                       class="inline-flex items-center gap-1 rounded-lg bg-indigo-500/10 px-3 py-1.5 text-xs font-semibold text-indigo-600 hover:bg-indigo-500/20">
                                        <i class="fas fa-pen-to-square"></i>
                                        <?php echo e(__('admin.trips.actions.edit')); ?>

                                    </a>
                                    <form method="POST" action="<?php echo e(route('admin.trips.destroy', $trip)); ?>"
                                          onsubmit="return confirm('<?php echo e(__('admin.trips.messages.deleted')); ?>')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                                class="inline-flex items-center gap-1 rounded-lg bg-rose-500/10 px-3 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-500/20">
                                            <i class="fas fa-trash"></i>
                                            <?php echo e(__('admin.trips.actions.delete')); ?>

                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="px-4 py-6 text-center text-sm text-slate-500">
                                <?php echo e(__('admin.trips.empty')); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-6">
            <?php echo e($trips->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/admin/trips/index.blade.php ENDPATH**/ ?>