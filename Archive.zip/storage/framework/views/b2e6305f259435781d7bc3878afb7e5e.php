<?php $__env->startSection('title', __('admin.payments.page_title')); ?>
<?php $__env->startSection('page-title', __('admin.payments.heading')); ?>
<?php $__env->startSection('page-subtitle', __('admin.payments.subheading')); ?>

<?php $__env->startSection('content'); ?>
    <div class="rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-lg font-semibold text-slate-900"><?php echo e(__('admin.payments.heading')); ?></h2>
                <p class="text-sm text-slate-500"><?php echo e(__('admin.payments.subheading')); ?></p>
            </div>
        </div>

        
        <form method="GET" action="<?php echo e(route('admin.payments.index')); ?>" class="mt-6 space-y-4">
            <div class="grid gap-4 sm:grid-cols-3">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                       placeholder="<?php echo e(__('admin.payments.search_placeholder')); ?>"
                       class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                
                <select name="status" class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                    <option value=""><?php echo e(__('admin.payments.all_statuses')); ?></option>
                    <option value="pending" <?php echo e(request('status') === 'pending' ? 'selected' : ''); ?>><?php echo e(__('admin.payments.status.pending')); ?></option>
                    <option value="completed" <?php echo e(request('status') === 'completed' ? 'selected' : ''); ?>><?php echo e(__('admin.payments.status.completed')); ?></option>
                    <option value="failed" <?php echo e(request('status') === 'failed' ? 'selected' : ''); ?>><?php echo e(__('admin.payments.status.failed')); ?></option>
                    <option value="refunded" <?php echo e(request('status') === 'refunded' ? 'selected' : ''); ?>><?php echo e(__('admin.payments.status.refunded')); ?></option>
                </select>

                <select name="payment_method" class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                    <option value=""><?php echo e(__('admin.payments.all_methods')); ?></option>
                    <option value="cash" <?php echo e(request('payment_method') === 'cash' ? 'selected' : ''); ?>><?php echo e(__('admin.payments.payment_method.cash')); ?></option>
                    <option value="card" <?php echo e(request('payment_method') === 'card' ? 'selected' : ''); ?>><?php echo e(__('admin.payments.payment_method.card')); ?></option>
                    <option value="bank_transfer" <?php echo e(request('payment_method') === 'bank_transfer' ? 'selected' : ''); ?>><?php echo e(__('admin.payments.payment_method.bank_transfer')); ?></option>
                    <option value="online" <?php echo e(request('payment_method') === 'online' ? 'selected' : ''); ?>><?php echo e(__('admin.payments.payment_method.online')); ?></option>
                    <option value="other" <?php echo e(request('payment_method') === 'other' ? 'selected' : ''); ?>><?php echo e(__('admin.payments.payment_method.other')); ?></option>
                </select>
            </div>

            <div class="flex items-center gap-2">
                <button type="submit"
                        class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-slate-700">
                    <i class="fas fa-search"></i>
                    <?php echo e(__('admin.payments.search')); ?>

                </button>
                <?php if(request()->anyFilled(['search', 'status', 'payment_method'])): ?>
                    <a href="<?php echo e(route('admin.payments.index')); ?>"
                       class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
                        <i class="fas fa-times"></i>
                        <?php echo e(__('admin.bookings.clear_filters')); ?>

                    </a>
                <?php endif; ?>
            </div>
        </form>

        <div class="mt-6 overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200 text-right text-sm">
                <thead class="bg-slate-50 text-xs font-medium uppercase tracking-wider text-slate-500">
                    <tr>
                        <th class="px-4 py-3"><?php echo e(__('admin.payments.table.id')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.payments.table.booking')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.payments.table.amount')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.payments.table.payment_method')); ?></th>
                        <th class="px-4 py-3 text-center"><?php echo e(__('admin.payments.table.status')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.payments.table.paid_at')); ?></th>
                        <th class="px-4 py-3 text-center"><?php echo e(__('admin.payments.table.actions')); ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 bg-white">
                    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-4 py-4 font-mono text-xs font-semibold text-slate-800">
                                #<?php echo e($payment->id); ?>

                            </td>
                            <td class="px-4 py-4">
                                <div>
                                    <p class="font-semibold text-slate-900"><?php echo e($payment->booking->booking_reference); ?></p>
                                    <p class="text-xs text-slate-500"><?php echo e($payment->booking->user->name); ?></p>
                                </div>
                            </td>
                            <td class="px-4 py-4 font-semibold text-slate-900">
                                <?php echo e(number_format($payment->amount, 2)); ?> <?php echo e(__('admin.payments.currency')); ?>

                            </td>
                            <td class="px-4 py-4 text-slate-600">
                                <?php echo e(__('admin.payments.payment_method.' . $payment->payment_method)); ?>

                            </td>
                            <td class="px-4 py-4 text-center">
                                <?php
                                    $statusClasses = [
                                        'pending' => 'bg-yellow-50 text-yellow-600',
                                        'completed' => 'bg-emerald-50 text-emerald-600',
                                        'failed' => 'bg-rose-50 text-rose-600',
                                        'refunded' => 'bg-slate-100 text-slate-600',
                                    ];
                                    $statusClass = $statusClasses[$payment->status] ?? 'bg-slate-100 text-slate-600';
                                ?>
                                <span class="inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold <?php echo e($statusClass); ?>">
                                    <?php echo e(__('admin.payments.status.' . $payment->status)); ?>

                                </span>
                            </td>
                            <td class="px-4 py-4 text-slate-600">
                                <?php echo e($payment->paid_at ? $payment->paid_at->format('Y-m-d H:i') : '-'); ?>

                            </td>
                            <td class="px-4 py-4 text-center">
                                <a href="<?php echo e(route('admin.payments.show', $payment)); ?>"
                                   class="inline-flex items-center gap-1 rounded-lg bg-indigo-500/10 px-3 py-1.5 text-xs font-semibold text-indigo-600 hover:bg-indigo-500/20">
                                    <i class="fas fa-eye"></i>
                                    <?php echo e(__('admin.payments.show_title')); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-4 py-6 text-center text-sm text-slate-500">
                                <?php echo e(__('admin.payments.empty')); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-6">
            <?php echo e($payments->appends(request()->query())->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/admin/payments/index.blade.php ENDPATH**/ ?>