<?php $__env->startSection('title', __('admin.privacy.page_title')); ?>
<?php $__env->startSection('page-title', __('admin.privacy.heading')); ?>
<?php $__env->startSection('page-subtitle', __('admin.privacy.intro')); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $sections = __('admin.privacy.sections');
    ?>

    <div class="space-y-6">
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="rounded-3xl border border-slate-200/80 bg-white/80 p-6 shadow-lg shadow-slate-100/60 backdrop-blur">
                <div class="flex items-start gap-4">
                    <span class="inline-flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-2xl bg-sky-500/10 text-sky-500 text-xl">
                        <i class="fas fa-shield"></i>
                    </span>
                    <div>
                        <h2 class="text-lg font-semibold text-slate-900"><?php echo e($section['title']); ?></h2>
                        <ul class="mt-4 space-y-2 text-sm leading-relaxed text-slate-600">
                            <?php $__currentLoopData = $section['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex items-start gap-2">
                                    <span class="mt-1 inline-flex h-2 w-2 flex-shrink-0 rounded-full bg-sky-400"></span>
                                    <span><?php echo e($item); ?></span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-8 rounded-3xl border border-emerald-200/70 bg-emerald-50/70 px-6 py-5 text-sm font-medium text-emerald-800 shadow-sm shadow-emerald-200/40">
        <i class="fas fa-headset ms-2"></i>
        <?php echo e(__('admin.privacy.contact')); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/admin/pages/privacy.blade.php ENDPATH**/ ?>