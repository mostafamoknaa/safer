<?php $__env->startSection('title', __('admin.conversations.page_title')); ?>
<?php $__env->startSection('page-title', __('admin.conversations.heading')); ?>
<?php $__env->startSection('page-subtitle', __('admin.conversations.subheading')); ?>

<?php $__env->startSection('content'); ?>
    <div class="rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-lg font-semibold text-slate-900"><?php echo e(__('admin.conversations.heading')); ?></h2>
                <p class="text-sm text-slate-500"><?php echo e(__('admin.conversations.subheading')); ?></p>
            </div>
            <?php if($unreadCount > 0): ?>
                <div class="inline-flex items-center gap-2 rounded-xl bg-rose-500/10 px-4 py-2 text-sm font-semibold text-rose-600">
                    <i class="fas fa-envelope"></i>
                    <span><?php echo e($unreadCount); ?> <?php echo e(__('admin.conversations.unread_messages')); ?></span>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="mt-6 grid gap-4 sm:grid-cols-2">
            <form method="GET" action="<?php echo e(route('admin.conversations.index')); ?>" class="flex items-center gap-2">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                       placeholder="<?php echo e(__('admin.conversations.search_placeholder')); ?>"
                       class="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                <button type="submit"
                        class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-slate-700">
                    <i class="fas fa-search"></i>
                    <?php echo e(__('admin.conversations.search')); ?>

                </button>
                <?php if(request('search')): ?>
                    <a href="<?php echo e(route('admin.conversations.index')); ?>"
                       class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
                        <i class="fas fa-times"></i>
                    </a>
                <?php endif; ?>
            </form>

            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('admin.conversations.index', ['status' => 'open'])); ?>"
                   class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                       'inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition',
                       'bg-emerald-500 text-white' => request('status') === 'open',
                       'border border-slate-200 bg-white text-slate-600 hover:bg-slate-100' => request('status') !== 'open',
                   ]); ?>">
                    <i class="fas fa-comments"></i>
                    <?php echo e(__('admin.conversations.open')); ?>

                </a>
                <a href="<?php echo e(route('admin.conversations.index', ['status' => 'closed'])); ?>"
                   class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                       'inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition',
                       'bg-slate-500 text-white' => request('status') === 'closed',
                       'border border-slate-200 bg-white text-slate-600 hover:bg-slate-100' => request('status') !== 'closed',
                   ]); ?>">
                    <i class="fas fa-archive"></i>
                    <?php echo e(__('admin.conversations.closed')); ?>

                </a>
                <?php if(request('status')): ?>
                    <a href="<?php echo e(route('admin.conversations.index')); ?>"
                       class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
                        <?php echo e(__('admin.conversations.all')); ?>

                    </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="mt-6 overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200 text-right text-sm">
                <thead class="bg-slate-50 text-xs font-medium uppercase tracking-wider text-slate-500">
                    <tr>
                        <th class="px-4 py-3"><?php echo e(__('admin.conversations.table.user')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.conversations.table.last_message')); ?></th>
                        <th class="px-4 py-3"><?php echo e(__('admin.conversations.table.last_message_at')); ?></th>
                        <th class="px-4 py-3 text-center"><?php echo e(__('admin.conversations.table.status')); ?></th>
                        <th class="px-4 py-3 text-center"><?php echo e(__('admin.conversations.table.actions')); ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 bg-white">
                    <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $unreadCount = $conversation->messages()->where('sender_type', 'user')->where('is_read', false)->count();
                        ?>
                        <tr class="<?php echo \Illuminate\Support\Arr::toCssClasses(['bg-rose-50/50' => $unreadCount > 0]); ?>">
                            <td class="px-4 py-4">
                                <div class="flex items-center gap-3">
                                    <div class="flex h-10 w-10 items-center justify-center rounded-full bg-indigo-500/10 text-indigo-600">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div>
                                        <div class="font-semibold text-slate-800"><?php echo e($conversation->user->name); ?></div>
                                        <div class="text-xs text-slate-500"><?php echo e($conversation->user->email); ?></div>
                                    </div>
                                    <?php if($unreadCount > 0): ?>
                                        <span class="inline-flex items-center justify-center rounded-full bg-rose-500 text-xs font-semibold text-white h-5 w-5">
                                            <?php echo e($unreadCount); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-4 py-4 text-slate-600">
                                <?php if($conversation->lastMessage): ?>
                                    <div class="flex items-center gap-2">
                                        <?php if($conversation->lastMessage->type === 'file'): ?>
                                            <i class="fas fa-file text-slate-400"></i>
                                        <?php endif; ?>
                                        <span class="truncate max-w-xs">
                                            <?php echo e(\Illuminate\Support\Str::limit($conversation->lastMessage->message, 50)); ?>

                                        </span>
                                    </div>
                                <?php else: ?>
                                    <span class="text-slate-400">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-4 text-slate-600 text-xs">
                                <?php if($conversation->last_message_at): ?>
                                    <?php echo e($conversation->last_message_at->diffForHumans()); ?>

                                <?php else: ?>
                                    <span class="text-slate-400">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-4 text-center">
                                <?php if($conversation->status === 'open'): ?>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-600">
                                        <span class="h-2 w-2 rounded-full bg-emerald-500"></span>
                                        <?php echo e(__('admin.conversations.badges.open')); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-500">
                                        <span class="h-2 w-2 rounded-full bg-slate-400"></span>
                                        <?php echo e(__('admin.conversations.badges.closed')); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-4 text-center">
                                <div class="flex items-center justify-center gap-2">
                                    <a href="<?php echo e(route('admin.conversations.show', $conversation)); ?>"
                                       class="inline-flex items-center gap-1 rounded-lg bg-indigo-500/10 px-3 py-1.5 text-xs font-semibold text-indigo-600 hover:bg-indigo-500/20">
                                        <i class="fas fa-comment-dots"></i>
                                        <?php echo e(__('admin.conversations.actions.open')); ?>

                                    </a>
                                    <?php if($conversation->status === 'open'): ?>
                                        <form method="POST" action="<?php echo e(route('admin.conversations.close', $conversation)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit"
                                                    class="inline-flex items-center gap-1 rounded-lg bg-slate-500/10 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-500/20">
                                                <i class="fas fa-archive"></i>
                                                <?php echo e(__('admin.conversations.actions.close')); ?>

                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-4 py-6 text-center text-sm text-slate-500">
                                <?php echo e(__('admin.conversations.empty')); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-6">
            <?php echo e($conversations->appends(request()->query())->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/admin/conversations/index.blade.php ENDPATH**/ ?>