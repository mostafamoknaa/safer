<?php
    $editing = isset($contactLink);
?>

<div class="grid gap-6">
    <div class="grid gap-2">
        <label for="type" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.contact_links.form.type')); ?>

        </label>
        <input id="type" name="type" type="text"
               value="<?php echo e(old('type', $contactLink->type ?? '')); ?>"
               class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-200"
               required>
        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="grid gap-2 sm:grid-cols-2 sm:gap-4">
        <div class="grid gap-2">
            <label for="title_ar" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.contact_links.form.title_ar')); ?>

            </label>
            <input id="title_ar" name="title_ar" type="text"
                   value="<?php echo e(old('title_ar', $contactLink->title_ar ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-200"
                   required>
            <?php $__errorArgs = ['title_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="grid gap-2">
            <label for="title_en" class="text-sm font-medium text-slate-600">
                <?php echo e(__('admin.contact_links.form.title_en')); ?>

            </label>
            <input id="title_en" name="title_en" type="text"
                   value="<?php echo e(old('title_en', $contactLink->title_en ?? '')); ?>"
                   class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-200"
                   required>
            <?php $__errorArgs = ['title_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid gap-2">
        <label for="url" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.contact_links.form.url')); ?>

        </label>
        <input id="url" name="url" type="url"
               value="<?php echo e(old('url', $contactLink->url ?? '')); ?>"
               class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-200"
               required>
        <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="grid gap-2">
        <label for="icon" class="text-sm font-medium text-slate-600">
            <?php echo e(__('admin.contact_links.form.icon')); ?>

        </label>
        <input id="icon" name="icon" type="text"
               value="<?php echo e(old('icon', $contactLink->icon ?? '')); ?>"
               class="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm text-slate-800 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-200"
               placeholder="fas fa-link">
        <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-rose-600"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <label class="inline-flex items-center gap-2 text-sm font-medium text-slate-600">
        <input type="checkbox" name="is_active" value="1"
               <?php if(old('is_active', $contactLink->is_active ?? true)): echo 'checked'; endif; ?>
               class="h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500">
        <?php echo e(__('admin.contact_links.form.is_active')); ?>

    </label>

    <div class="flex items-center justify-end gap-3">
        <a href="<?php echo e(route('admin.contact-links.index')); ?>"
           class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
            <?php echo e(__('admin.contact_links.actions.cancel')); ?>

        </a>
        <button type="submit"
                class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-slate-400/40 transition hover:bg-slate-700">
            <i class="fas fa-floppy-disk"></i>
            <?php echo e($editing ? __('admin.contact_links.actions.update') : __('admin.contact_links.actions.store')); ?>

        </button>
    </div>
</div>

<?php /**PATH /Volumes/D/project/safer/resources/views/admin/contact-links/_form.blade.php ENDPATH**/ ?>