<?php $__env->startSection('title', __('admin.users.manage_hotels')); ?>
<?php $__env->startSection('page-title', __('admin.users.manage_hotels')); ?>
<?php $__env->startSection('page-subtitle', __('admin.users.manage_hotels_subtitle', ['user' => $user->name])); ?>

<?php $__env->startSection('content'); ?>
    <div class="rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-6">
            <div>
                <h2 class="text-lg font-semibold text-slate-900"><?php echo e(__('admin.users.manage_hotels')); ?></h2>
                <p class="text-sm text-slate-500"><?php echo e(__('admin.users.manage_hotels_subtitle', ['user' => $user->name])); ?></p>
            </div>
            <a href="<?php echo e(route('admin.users.index')); ?>"
               class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
                <i class="fas fa-arrow-right"></i>
                <?php echo e(__('admin.users.back_to_list')); ?>

            </a>
        </div>

        <form method="POST" action="<?php echo e(route('admin.users.update-hotels', $user)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="grid gap-4">
                <div class="grid gap-2">
                    <label class="text-sm font-medium text-slate-600">
                        <?php echo e(__('admin.users.select_hotels')); ?>

                    </label>
                    <div class="grid gap-3 max-h-96 overflow-y-auto border border-slate-200 rounded-xl p-4">
                        <?php $__empty_1 = true; $__currentLoopData = $allHotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <label class="flex items-center gap-3 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer">
                                <input type="checkbox" name="hotels[]" value="<?php echo e($hotel->id); ?>"
                                       <?php if(in_array($hotel->id, $userHotels)): echo 'checked'; endif; ?>
                                       class="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500">
                                <div class="flex-1">
                                    <div class="font-semibold text-slate-800">
                                        <?php echo e(app()->getLocale() === 'ar' ? $hotel->name_ar : $hotel->name_en); ?>

                                    </div>
                                    <div class="text-xs text-slate-500">
                                        <?php echo e(app()->getLocale() === 'ar' ? ($hotel->province->name_ar ?? '-') : ($hotel->province->name_en ?? '-')); ?>

                                    </div>
                                </div>
                                <?php if(in_array($hotel->id, $userHotels)): ?>
                                    <span class="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-600">
                                        <span class="h-2 w-2 rounded-full bg-emerald-500"></span>
                                        <?php echo e(__('admin.users.assigned')); ?>

                                    </span>
                                <?php endif; ?>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-slate-500 text-center py-4"><?php echo e(__('admin.users.no_hotels_available')); ?></p>
                        <?php endif; ?>
                    </div>
                    <p class="text-xs text-slate-400"><?php echo e(__('admin.users.hotels_selection_hint')); ?></p>
                </div>

                <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                    <a href="<?php echo e(route('admin.users.index')); ?>"
                       class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
                        <?php echo e(__('admin.users.cancel')); ?>

                    </a>
                    <button type="submit"
                            class="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-6 py-2 text-sm font-semibold text-white shadow-md shadow-indigo-400/40 transition hover:bg-indigo-700">
                        <i class="fas fa-save"></i>
                        <?php echo e(__('admin.users.save')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/D/project/safer/resources/views/admin/users/manage-hotels.blade.php ENDPATH**/ ?>