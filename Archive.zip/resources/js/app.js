import './bootstrap';
import 'trix';

document.addEventListener('trix-file-accept', (event) => {
    event.preventDefault();
});
