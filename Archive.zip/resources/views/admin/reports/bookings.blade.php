@extends('layouts.admin')

@section('title', __('admin.reports.bookings.page_title'))
@section('page-title', __('admin.reports.bookings.heading'))
@section('page-subtitle', __('admin.reports.bookings.subheading'))

@section('content')
    <div class="rounded-3xl border border-slate-200/80 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-lg font-semibold text-slate-900">{{ __('admin.reports.bookings.heading') }}</h2>
                <p class="text-sm text-slate-500">{{ __('admin.reports.bookings.subheading') }}</p>
            </div>
            <div class="flex flex-wrap items-center gap-3">
                <form method="GET" action="{{ route('admin.reports.bookings') }}">
                    @foreach(request()->except('export') as $key => $value)
                        <input type="hidden" name="{{ $key }}" value="{{ $value }}">
                    @endforeach
                    <button type="submit" name="export" value="csv"
                            class="inline-flex items-center gap-2 rounded-xl bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-700 shadow-sm hover:bg-emerald-100">
                        <i class="fas fa-file-csv"></i>
                        {{ __('admin.reports.bookings.actions.download_csv') }}
                    </button>
                </form>
            </div>
        </div>

        {{-- Quick navigation between reports --}}
        <div class="mt-4 flex flex-wrap gap-2 text-xs">
            <a href="{{ route('admin.reports.bookings') }}" class="inline-flex items-center gap-1 rounded-full bg-slate-900 px-3 py-1.5 font-semibold text-white">
                <i class="fas fa-calendar-check"></i> {{ __('admin.reports.nav.bookings') }}
            </a>
            <a href="{{ route('admin.reports.payments') }}" class="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1.5 font-semibold text-slate-700 hover:bg-slate-200">
                <i class="fas fa-credit-card"></i> {{ __('admin.reports.nav.payments') }}
            </a>
            <a href="{{ route('admin.reports.services') }}" class="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1.5 font-semibold text-slate-700 hover:bg-slate-200">
                <i class="fas fa-clipboard-list"></i> {{ __('admin.reports.nav.services') }}
            </a>
            <a href="{{ route('admin.reports.events') }}" class="inline-flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1.5 font-semibold text-slate-700 hover:bg-slate-200">
                <i class="fas fa-calendar-alt"></i> {{ __('admin.reports.nav.events') }}
            </a>
        </div>

        {{-- Filters --}}
        <form method="GET" action="{{ route('admin.reports.bookings') }}" class="mt-6 space-y-4">
            <div class="grid gap-4 md:grid-cols-5">
                <div class="grid gap-2">
                    <label for="from_date" class="text-xs font-medium text-slate-500">
                        {{ __('admin.reports.bookings.filters.from_date') }}
                    </label>
                    <input id="from_date" name="from_date" type="date"
                           value="{{ request('from_date') }}"
                           class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                </div>

                <div class="grid gap-2">
                    <label for="to_date" class="text-xs font-medium text-slate-500">
                        {{ __('admin.reports.bookings.filters.to_date') }}
                    </label>
                    <input id="to_date" name="to_date" type="date"
                           value="{{ request('to_date') }}"
                           class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                </div>

                <div class="grid gap-2">
                    <label for="status" class="text-xs font-medium text-slate-500">
                        {{ __('admin.reports.bookings.filters.status') }}
                    </label>
                    <select id="status" name="status"
                            class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                        <option value="">{{ __('admin.reports.bookings.filters.all_statuses') }}</option>
                        <option value="pending" @selected(request('status') === 'pending')>{{ __('admin.bookings.badges.pending') }}</option>
                        <option value="confirmed" @selected(request('status') === 'confirmed')>{{ __('admin.bookings.badges.confirmed') }}</option>
                        <option value="completed" @selected(request('status') === 'completed')>{{ __('admin.bookings.badges.completed') }}</option>
                        <option value="cancelled" @selected(request('status') === 'cancelled')>{{ __('admin.bookings.badges.cancelled') }}</option>
                    </select>
                </div>

                <div class="grid gap-2">
                    <label for="hotel_id" class="text-xs font-medium text-slate-500">
                        {{ __('admin.reports.bookings.filters.hotel') }}
                    </label>
                    <select id="hotel_id" name="hotel_id"
                            class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                        <option value="">{{ __('admin.reports.bookings.filters.all_hotels') }}</option>
                        @foreach($hotels as $hotel)
                            <option value="{{ $hotel->id }}" @selected(request('hotel_id') == $hotel->id)>
                                {{ app()->getLocale() === 'ar' ? $hotel->name_ar : $hotel->name_en }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="grid gap-2">
                    <label for="user_id" class="text-xs font-medium text-slate-500">
                        {{ __('admin.reports.bookings.filters.user') }}
                    </label>
                    <select id="user_id" name="user_id"
                            class="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-200">
                        <option value="">{{ __('admin.reports.bookings.filters.all_users') }}</option>
                        @foreach($users as $user)
                            <option value="{{ $user->id }}" @selected(request('user_id') == $user->id)>
                                {{ $user->name }} ({{ $user->email }})
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="flex items-center justify-end gap-3">
                <a href="{{ route('admin.reports.bookings') }}"
                   class="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100">
                    <i class="fas fa-rotate"></i>
                    {{ __('admin.reports.bookings.actions.reset') }}
                </a>
                <button type="submit"
                        class="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-slate-400/40 transition hover:bg-slate-700">
                    <i class="fas fa-search"></i>
                    {{ __('admin.reports.bookings.actions.filter') }}
                </button>
            </div>
        </form>

        {{-- Table --}}
        <div class="mt-6 overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200 text-right text-sm">
                <thead class="bg-slate-50 text-xs font-medium uppercase tracking-wider text-slate-500">
                    <tr>
                        <th class="px-4 py-3">{{ __('admin.bookings.table.reference') }}</th>
                        <th class="px-4 py-3">{{ __('admin.bookings.table.user') }}</th>
                        <th class="px-4 py-3">{{ __('admin.bookings.table.hotel') }}</th>
                        <th class="px-4 py-3">{{ __('admin.bookings.table.room') }}</th>
                        <th class="px-4 py-3">{{ __('admin.bookings.table.check_in_date') }}</th>
                        <th class="px-4 py-3">{{ __('admin.bookings.table.check_out_date') }}</th>
                        <th class="px-4 py-3">{{ __('admin.bookings.table.status') }}</th>
                        <th class="px-4 py-3">{{ __('admin.bookings.table.total_price') }}</th>
                        <th class="px-4 py-3">{{ __('admin.bookings.table.created_at') }}</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 bg-white">
                    @forelse($bookings as $booking)
                        <tr>
                            <td class="px-4 py-3 font-mono text-xs text-slate-600">
                                {{ $booking->booking_reference }}
                            </td>
                            <td class="px-4 py-3 text-slate-800">
                                {{ $booking->user?->name }}
                            </td>
                            <td class="px-4 py-3 text-slate-700">
                                {{ $booking->hotel ? (app()->getLocale() === 'ar' ? $booking->hotel->name_ar : $booking->hotel->name_en) : '-' }}
                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                {{ $booking->room_id ?? '-' }}
                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                {{ optional($booking->check_in_date)->format('Y-m-d') }}
                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                {{ optional($booking->check_out_date)->format('Y-m-d') }}
                            </td>
                            <td class="px-4 py-3">
                                @include('admin.bookings._status_badge', ['status' => $booking->status])
                            </td>
                            <td class="px-4 py-3 font-semibold text-slate-900">
                                {{ number_format($booking->total_price, 2) }} {{ __('admin.bookings.currency') }}
                            </td>
                            <td class="px-4 py-3 text-xs text-slate-500">
                                {{ optional($booking->created_at)->format('Y-m-d H:i') }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="9" class="px-4 py-6 text-center text-sm text-slate-500">
                                {{ __('admin.reports.bookings.empty') }}
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-6">
            {{ $bookings->links() }}
        </div>
    </div>
@endsection


