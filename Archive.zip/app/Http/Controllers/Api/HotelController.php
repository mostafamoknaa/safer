<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Hotel;
use App\Models\HotelRoom;
use App\Models\Province;
use App\Models\Booking;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class HotelController extends Controller
{
    /**
     * Get all provinces.
     */
    public function getProvinces(): JsonResponse
    {
        $provinces = Province::where('is_active', true)
            ->orderBy('name_ar')
            ->get()
            ->map(function ($province) {
                return [
                    'id' => $province->id,
                    'name' => app()->getLocale() === 'ar' ? $province->name_ar : $province->name_en,
                ];
            });

        return response()->json([
            'success' => true,
            'data' => $provinces,
        ]);
    }

    /**
     * Get available hotels with filters.
     */
    public function getHotels(Request $request): JsonResponse
    {
        $query = Hotel::with(['province', 'rooms'])
            ->where('is_active', true);

        // Filter by province
        if ($request->filled('province_id')) {
            $query->where('province_id', $request->province_id);
        }

        // Search by name
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name_ar', 'like', "%{$search}%")
                    ->orWhere('name_en', 'like', "%{$search}%");
            });
        }

        $hotels = $query->orderBy('name_ar')
            ->get()
            ->map(function ($hotel) {
                return [
                    'id' => $hotel->id,
                    'name' => app()->getLocale() === 'ar' ? $hotel->name_ar : $hotel->name_en,
                    'address' => app()->getLocale() === 'ar' ? $hotel->address_ar : $hotel->address_en,
                    'province' => $hotel->province ? [
                        'id' => $hotel->province->id,
                        'name' => app()->getLocale() === 'ar' ? $hotel->province->name_ar : $hotel->province->name_en,
                    ] : null,
                    'website_url' => $hotel->website_url,
                    'about_info' => app()->getLocale() === 'ar' ? $hotel->about_info_ar : $hotel->about_info_en,
                    'rooms_count' => $hotel->rooms()->where('is_active', true)->count(),
                    'min_price' => $hotel->rooms()->where('is_active', true)->min('price_per_night') ? (float) $hotel->rooms()->where('is_active', true)->min('price_per_night') : null,
                    'max_price' => $hotel->rooms()->where('is_active', true)->max('price_per_night') ? (float) $hotel->rooms()->where('is_active', true)->max('price_per_night') : null,
                ];
            });

        return response()->json([
            'success' => true,
            'data' => $hotels,
        ]);
    }

    /**
     * Get hotel details with rooms and media.
     */
    public function getHotelDetails(Hotel $hotel): JsonResponse
    {
        if (!$hotel->is_active) {
            return response()->json([
                'success' => false,
                'message' => __('api.hotels.hotel_not_available'),
            ], 404);
        }

        $hotel->load(['province', 'media', 'rooms' => function ($query) {
            $query->where('is_active', true);
        }]);

        $rooms = $hotel->rooms->map(function ($room) {
            return [
                'id' => $room->id,
                'price_per_night' => (float) $room->price_per_night,
                'beds_count' => $room->beds_count,
                'bathrooms_count' => $room->bathrooms_count,
                'rooms_count' => $room->rooms_count,
            ];
        });

        $images = $hotel->media->where('type', 'image')->map(function ($media) {
            return [
                'url' => $media->file_url,
                'order' => $media->order_column,
            ];
        })->sortBy('order')->values();

        $videos = $hotel->media->where('type', 'video')->map(function ($media) {
            return [
                'url' => $media->file_url,
                'order' => $media->order_column,
            ];
        })->sortBy('order')->values();

        return response()->json([
            'success' => true,
            'data' => [
                'id' => $hotel->id,
                'name' => app()->getLocale() === 'ar' ? $hotel->name_ar : $hotel->name_en,
                'address' => app()->getLocale() === 'ar' ? $hotel->address_ar : $hotel->address_en,
                'province' => $hotel->province ? [
                    'id' => $hotel->province->id,
                    'name' => app()->getLocale() === 'ar' ? $hotel->province->name_ar : $hotel->province->name_en,
                ] : null,
                'website_url' => $hotel->website_url,
                'about_info' => app()->getLocale() === 'ar' ? $hotel->about_info_ar : $hotel->about_info_en,
                'images' => $images,
                'videos' => $videos,
                'rooms' => $rooms,
            ],
        ]);
    }

    /**
     * Get hotel rooms.
     */
    public function getHotelRooms(Hotel $hotel, Request $request): JsonResponse
    {
        if (!$hotel->is_active) {
            return response()->json([
                'success' => false,
                'message' => __('api.hotels.hotel_not_available'),
            ], 404);
        }

        $query = $hotel->rooms()->where('is_active', true);

        // Filter by price range
        if ($request->filled('min_price')) {
            $query->where('price_per_night', '>=', $request->min_price);
        }

        if ($request->filled('max_price')) {
            $query->where('price_per_night', '<=', $request->max_price);
        }

        // Filter by beds count
        if ($request->filled('beds_count')) {
            $query->where('beds_count', '>=', $request->beds_count);
        }

        // Filter by availability dates
        if ($request->filled('check_in_date') && $request->filled('check_out_date')) {
            $checkIn = $request->check_in_date;
            $checkOut = $request->check_out_date;

            $query->whereDoesntHave('bookings', function ($q) use ($checkIn, $checkOut) {
                $q->where(function ($bookingQuery) use ($checkIn, $checkOut) {
                    $bookingQuery->whereBetween('check_in_date', [$checkIn, $checkOut])
                        ->orWhereBetween('check_out_date', [$checkIn, $checkOut])
                        ->orWhere(function ($q) use ($checkIn, $checkOut) {
                            $q->where('check_in_date', '<=', $checkIn)
                                ->where('check_out_date', '>=', $checkOut);
                        });
                })
                ->whereIn('status', ['pending', 'confirmed', 'checked_in']);
            });
        }

        $rooms = $query->orderBy('price_per_night')
            ->get()
            ->map(function ($room) {
                $images = $room->media->where('type', 'image')->map(function ($media) {
                    return $media->file_url;
                })->values();

                return [
                    'id' => $room->id,
                    'price_per_night' => (float) $room->price_per_night,
                    'beds_count' => $room->beds_count,
                    'bathrooms_count' => $room->bathrooms_count,
                    'rooms_count' => $room->rooms_count,
                    'images' => $images,
                ];
            });

        return response()->json([
            'success' => true,
            'data' => $rooms,
        ]);
    }

    /**
     * Check room availability for specific dates.
     */
    public function checkRoomAvailability(Request $request): JsonResponse
    {
        $request->validate([
            'room_id' => 'required|exists:hotel_rooms,id',
            'check_in_date' => 'required|date|after_or_equal:today',
            'check_out_date' => 'required|date|after:check_in_date',
        ]);

        $room = HotelRoom::with('hotel')->findOrFail($request->room_id);

        if (!$room->is_active || !$room->hotel->is_active) {
            return response()->json([
                'success' => false,
                'message' => __('api.hotels.room_not_available'),
            ], 400);
        }

        // Check for conflicting bookings
        $conflictingBookings = Booking::where('room_id', $room->id)
            ->where(function ($q) use ($request) {
                $q->whereBetween('check_in_date', [$request->check_in_date, $request->check_out_date])
                    ->orWhereBetween('check_out_date', [$request->check_in_date, $request->check_out_date])
                    ->orWhere(function ($query) use ($request) {
                        $query->where('check_in_date', '<=', $request->check_in_date)
                            ->where('check_out_date', '>=', $request->check_out_date);
                    });
            })
            ->whereIn('status', ['pending', 'confirmed', 'checked_in'])
            ->exists();

        $isAvailable = !$conflictingBookings;

        $nights = max(1, \Carbon\Carbon::parse($request->check_in_date)->diffInDays($request->check_out_date));
        $totalPrice = $room->price_per_night * $nights;

        return response()->json([
            'success' => true,
            'data' => [
                'available' => $isAvailable,
                'room' => [
                    'id' => $room->id,
                    'price_per_night' => (float) $room->price_per_night,
                    'beds_count' => $room->beds_count,
                    'bathrooms_count' => $room->bathrooms_count,
                    'rooms_count' => $room->rooms_count,
                ],
                'nights' => $nights,
                'total_price' => $totalPrice,
            ],
        ]);
    }
}

